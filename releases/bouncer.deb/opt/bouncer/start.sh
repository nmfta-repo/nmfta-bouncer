#!/bin/bash

python3 /opt/bouncer/app/rest_interface.py
