#!/bin/bash

python3 /opt/bouncer/src/rest_interface.py
