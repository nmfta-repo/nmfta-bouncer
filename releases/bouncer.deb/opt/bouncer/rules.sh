#!/bin/bash

python3 /opt/bouncer/app/rules_scheduler.py /opt/bouncer/app/firewall.db
