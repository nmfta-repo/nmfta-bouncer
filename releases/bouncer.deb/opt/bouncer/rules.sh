#!/bin/bash

python3 /opt/bouncer/src/rules_scheduler.py /opt/bouncer/src/firewall.db
